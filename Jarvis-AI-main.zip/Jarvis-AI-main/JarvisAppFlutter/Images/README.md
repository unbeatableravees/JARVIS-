  <h2> JARVIS Splash Screen </h2>
    <img src="https://github.com/user-attachments/assets/cac80ec9-18a0-4708-bdc7-60bd0c0f1324" width="400" height="700"/>
  
  <br>
  
  
  ---

  <br>
  <br>
  
  ## JARVIS Start-mode home screen
  - Jarvis listens on continuously for the wake-up phrase 'Jarvis' or 'Hey Jarvis' </p>
  <img src="https://github.com/user-attachments/assets/d1d5ea13-ee26-47ab-bf95-d9d6743a0f9d" width="400" height="700"/>
  
  --- 
  
  <br>
  
  ## JARVIS Active Conversation mode screen
  - Jarvis will now engage in continuous coversation, it will listen and respond unless 'goodbye' or 'bye' gets triggered. </p> 
  <img src="https://github.com/user-attachments/assets/0746e510-cd78-4e5b-aa59-3489fca159fd" width="400" height="700"/>

  ## JARVIS Exit Screen ('Goodbye' / 'Bye' gets triggered)
  - Once 'Goodbye' or 'Bye' gets triggered, it returns back to the main home screen.
  - Conversation can be further continued on 'Hey Jarvis' / 'Jarvis' getting triggered.
  <img src="https://github.com/user-attachments/assets/0a8a2525-fcbe-4cee-8ac5-827dbb8a9427" width="400" height="700"/>
